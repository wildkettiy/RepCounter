local frame = CreateFrame("Frame", "RepCounterFrame", UIParent)
frame:SetSize(280, 100)
frame:SetPoint("CENTER", 0, 0)
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = { left = 4, right = 4, top = 4, bottom = 4 }
})
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
title:SetPoint("TOP", 0, -10)
title:SetText("RepCounter")

local content = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
content:SetPoint("TOPLEFT", 12, -30)
content:SetJustifyH("LEFT")
content:SetText("|cffaaaaaaWarte auf Ruf-Ereignis...|r")

local activeFactions = {}
local lastUpdate = 0
local TIMEOUT = 300
local standingNames = { [0]="Hasserfüllt", [1]="Feindselig", [2]="Unfreundlich", [3]="Neutral", [4]="Freundlich", [5]="Wohlwollend", [6]="Respektvoll", [7]="Ehrfürchtig" }

local function GetRemainingRep(factionName)
    for i = 1, GetNumFactions() do
        local name, _, standingID, bottomValue, topValue, earnedValue = GetFactionInfo(i)
        if name and (factionName:find(name) or name:find(factionName)) then
            local nextRank = (standingID < 7) and standingNames[standingID + 1] or "Ehrfürchtig"
            if standingID >= 8 then
                local currentRep = earnedValue - bottomValue
                return (999 - currentRep), "Ehrfürchtig", currentRep
            end
            return topValue - earnedValue, nextRank, nil
        end
    end
    return nil, nil, nil
end

local function UpdateDisplay()
    local sortedList = {}
    for name, data in pairs(activeFactions) do
        table.insert(sortedList, { 
            name = name, amount = data.amount, mobs = data.mobs, 
            nextRank = data.nextRank, currentRep = data.currentRep 
        })
    end
    table.sort(sortedList, function(a, b)
        return a.mobs < b.mobs
    end)
    local text = ""
    local count = 0
    for _, data in ipairs(sortedList) do
        count = count + 1
        local color = data.amount > 0 and "|cFF00FF00" or "|cFFFF0000"
        local mobSuffix = (data.mobs == 1) and "Mob" or "Mobs"
        if data.nextRank == "Ehrfürchtig" and data.currentRep then
            text = text .. string.format("|cFFFFD100%s|r: |cFF00FF00%d/1000 (Ehrfürchtig)|r\n", 
                data.name, data.currentRep)
        else
            text = text .. string.format("|cFFFFD100%s|r: %sNoch %d %s|r bis Ruf %s\n", 
                data.name, color, data.mobs, mobSuffix, data.nextRank)
        end
    end
    if count == 0 then
        content:SetText("|cffaaaaaaWarte auf Ruf-Ereignis...|r")
        frame:SetHeight(60)
    else
        content:SetText(text)
        frame:SetHeight(50 + (count * 15))
    end
end

frame:SetScript("OnUpdate", function(self, elapsed)
    if next(activeFactions) then
        lastUpdate = lastUpdate + elapsed
        if lastUpdate >= TIMEOUT then
            activeFactions = {}
            self:Hide()
            lastUpdate = 0
            UpdateDisplay()
        end
    end
end)

frame:RegisterEvent("CHAT_MSG_COMBAT_FACTION_CHANGE")
frame:SetScript("OnEvent", function(self, event, message)
    local faction, amountStr = message:match("Ruf bei (.*) hat sich um (%d+) ")
    if not faction then
        faction, amountStr = message:match("(.*) hat sich um (%d+) ")
    end
    if faction and amountStr then
        faction = faction:gsub("^der Fraktion ", ""):gsub("^den ", ""):gsub("^dem ", ""):gsub("^der ", ""):gsub("^die ", "")
        local amount = tonumber(amountStr)
        local isDecrease = message:find("verringert") or message:find("verschlechtert")
        if isDecrease then amount = -amount end
        local remaining, nextRank, currentRep = GetRemainingRep(faction)
        if remaining then
            if not activeFactions[faction] or math.abs(amount) <= 10 then
                activeFactions[faction] = activeFactions[faction] or {}
                activeFactions[faction].amount = amount
            end
            local baseAmount = math.abs(activeFactions[faction].amount)
            activeFactions[faction].mobs = math.ceil(remaining / baseAmount)
            activeFactions[faction].nextRank = nextRank
            activeFactions[faction].currentRep = currentRep
            lastUpdate = 0
            if not self:IsShown() then self:Show() end
            UpdateDisplay()
        end
    end
end)

SLASH_REPCOUNTER1 = "/repcounter"
SLASH_REPCOUNTER1 = "/rc"
SlashCmdList["REPCOUNTER"] = function()
    if frame:IsShown() then 
        frame:Hide() 
    else 
        frame:Show() 
        UpdateDisplay()
    end
end
SlashCmdList["RC"] = function()
    if frame:IsShown() then 
        frame:Hide() 
    else 
        frame:Show() 
        UpdateDisplay()
    end
end